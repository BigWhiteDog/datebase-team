-- error: col1 is exist in prepare.sql 
create table col1 (id int);
