-- error: miss data type -- 
create table col5 (id int, dis varchar, frequency    , token varchar, weight int);
