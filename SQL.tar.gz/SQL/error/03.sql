-- error: wrong data type -- 
create table col5 (id int, dis varchar, frequency int, token array, weight int);
