-- error: table does not exist
drop table col5;
