-- error: type miss matched  
insert into col2 values (13, 15);
