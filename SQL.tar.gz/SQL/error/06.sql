-- error: more field  
insert into col2 values (13, 'wrong', 16);
