-- error: table does not exist  
select id
from col5;
