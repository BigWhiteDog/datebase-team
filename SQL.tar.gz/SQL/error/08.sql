-- error: column does not exist  
select ColNotExist
from col4;
