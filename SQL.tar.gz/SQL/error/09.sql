-- error: field type does not matched  
select id
from col4
where  id like '1';
