drop table col1;
drop table col2;
drop table col4;
