-- select single column from small table
select id
from col1tab1;
