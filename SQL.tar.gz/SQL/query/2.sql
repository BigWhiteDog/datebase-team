-- select single column from medium table
select id, dist
from col3tab1
where frequency > 1;
