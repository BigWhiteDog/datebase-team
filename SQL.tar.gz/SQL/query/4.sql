-- select single column from medium table
select count(*)
from col2tab1;
