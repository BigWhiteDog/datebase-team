-- one to one join 
select col2tab1.id
from col2tab1, col2tab2
where col2tab1.id = col2tab2.id;
