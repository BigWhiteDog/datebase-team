select frequency
from col3tab1
where id > 0 
group by frequency;
