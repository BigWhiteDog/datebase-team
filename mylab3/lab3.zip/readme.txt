readme:

需要先 make test_meta 生成程序的元数据文件

然后再 make 生产 ucasdb
